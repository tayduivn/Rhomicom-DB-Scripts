create function somefunc1() returns integer
    language plpgsql
as
$$
<< outerblock >>
DECLARE
str text;
    quantity integer := 30;
BEGIN
    RAISE NOTICE 'Quantity here is %', quantity;  -- Prints 30
    str := chr(10)|| str || 'Quantity here is ' || chr(10)||'%' || quantity; 
    quantity := 50;
    --
    -- Create a subblock
    --
    DECLARE
        quantity integer := 80;
    BEGIN
        RAISE NOTICE 'Quantity here is %', quantity;  -- Prints 80
        str := chr(10)|| str || 'Quantity here is ' || chr(10)||'%' || quantity ;
        RAISE NOTICE 'Outer quantity here is %', outerblock.quantity;  -- Prints 50
        str := chr(10)|| str || 'Quantity here is ' || chr(10)||'%' || quantity; 
    END;

    RAISE NOTICE 'Quantity here is %', quantity;  -- Prints 50
    str := chr(10)|| str || 'Quantity here is ' || chr(10)||'%' || quantity ;

    RETURN str;
END;
$$;

alter function somefunc1() owner to postgres;

