create function somefunc2() returns text
    language plpgsql
as
$$
<< outerblock >>
DECLARE
str text:='Hello';
    quantity integer := 30;
BEGIN
    RAISE NOTICE 'Quantity here is %', quantity;  -- Prints 30
    str := str || ' Quantity here is ' || to_char(quantity,'99') ;
    quantity := 50;
    --
    -- Create a subblock
    --
    DECLARE
        quantity integer := 80;
    BEGIN
        RAISE NOTICE 'Quantity here is %', quantity;  -- Prints 80
        --str := chr(10)|| str || 'Quantity here is ' || chr(10)||'%' || quantity ;
        RAISE NOTICE 'Outer quantity here is %', outerblock.quantity;  -- Prints 50
        --str := chr(10)|| str || 'Quantity here is ' || chr(10)||'%' || quantity; 
    END;

    RAISE NOTICE  'Quantity here \n is %', quantity;  -- Prints 50
    str :=str || chr(10) || ' New Line Quantity here is \r\n ' || to_char(quantity,'99') ;
        RAISE NOTICE '%', str;
    RETURN str;
END;
$$;

alter function somefunc2() owner to postgres;

