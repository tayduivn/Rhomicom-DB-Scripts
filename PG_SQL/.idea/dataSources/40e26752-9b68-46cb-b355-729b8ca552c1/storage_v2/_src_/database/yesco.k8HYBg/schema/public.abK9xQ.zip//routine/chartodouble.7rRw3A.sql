create function chartodouble(charparam character varying) returns double precision
    language sql
as
$$
SELECT CASE WHEN trim($1) SIMILAR TO '[-+]?[0-9]*\.?[0-9]+([eE][-+]?[0-9]+)?' 
        THEN CAST(trim($1) AS double precision) 
    ELSE 0 END;

$$;

alter function chartodouble(varchar) owner to postgres;

