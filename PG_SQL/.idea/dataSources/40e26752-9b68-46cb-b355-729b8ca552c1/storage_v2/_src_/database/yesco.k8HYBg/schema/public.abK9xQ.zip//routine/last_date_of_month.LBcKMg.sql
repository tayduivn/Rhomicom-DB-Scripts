create function last_date_of_month(p_date character varying) returns character varying
    language plpgsql
as
$$
<< outerblock >>
    DECLARE
    bid CHARACTER VARYING(21) := '';
BEGIN
    SELECT to_char((date_trunc('MONTH', to_date(p_date, 'DD-Mon-YYYY')) + INTERVAL '1 MONTH - 1 day')::date,
                   'DD-Mon-YYYY')
    into bid;
    RETURN coalesce(bid, '');
EXCEPTION
    WHEN OTHERS THEN
        RETURN '';
END;
$$;

alter function last_date_of_month(varchar) owner to postgres;

