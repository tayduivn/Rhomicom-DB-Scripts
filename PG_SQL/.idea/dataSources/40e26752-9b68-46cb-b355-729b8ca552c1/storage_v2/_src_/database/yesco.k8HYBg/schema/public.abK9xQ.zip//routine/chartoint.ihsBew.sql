create function chartoint(charparam character varying) returns integer
    language sql
as
$$
SELECT CASE WHEN trim($1) SIMILAR TO '[0-9]+' 
        THEN CAST(trim($1) AS integer) 
    ELSE 0 END;

$$;

alter function chartoint(varchar) owner to postgres;

