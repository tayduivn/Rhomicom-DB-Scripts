create function get_frmtd_number(p_in_amnt numeric) returns character varying
    language plpgsql
as
$$
<< outerblock >>
    DECLARE
    bid character varying(500) := '';
BEGIN
    select trim(to_char(p_in_amnt, '999G999G999G999G999G999G990D00')) into bid;
    RETURN coalesce(bid, '');
END;
$$;

alter function get_frmtd_number(numeric) owner to postgres;

