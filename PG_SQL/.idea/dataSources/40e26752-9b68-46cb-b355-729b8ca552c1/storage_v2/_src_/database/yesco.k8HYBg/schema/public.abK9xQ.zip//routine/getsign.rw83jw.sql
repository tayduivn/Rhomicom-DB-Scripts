create function getsign(inptamnt numeric) returns numeric
    language plpgsql
as
$$
<< outerblock >>
  DECLARE
  v_res NUMERIC := 0;
BEGIN
  IF (inptAMnt != 0)
  THEN
    RETURN inptAMnt / abs(inptAMnt);
  END IF;
  RETURN 0;
  EXCEPTION
  WHEN OTHERS
    THEN
      RETURN 0;
END;

$$;

alter function getsign(numeric) owner to postgres;

