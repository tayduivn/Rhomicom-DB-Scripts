create function chartonumeric(charparam character varying) returns numeric
    language sql
as
$$
SELECT CASE
           WHEN trim(REPLACE($1, ',', '')) SIMILAR TO '[-+]?[0-9]*\.?[0-9]+([eE][-+]?[0-9]+)?'
               THEN CAST(trim(REPLACE($1, ',', '')) AS numeric)
           ELSE 0 END;
$$;

alter function chartonumeric(varchar) owner to postgres;

